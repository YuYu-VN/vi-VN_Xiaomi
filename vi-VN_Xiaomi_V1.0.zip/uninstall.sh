#!/bin/sh
# Author: Yu Yu
# -Begin-
# Variable
home="/data/adb/modules_update"
modules="/vi-VN_xiaomi"

# Script
rm -rf $home$modules
# --End--
